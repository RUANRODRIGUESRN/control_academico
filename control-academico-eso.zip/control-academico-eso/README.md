# 📚 Control Académico 1º ESO

Sistema completo de seguimiento y control académico para estudiantes de 1º de ESO.

## 🎯 Características

- ✅ Gestión de tareas y deberes
- 📚 Control de exámenes y notas
- 📊 Dashboard con estadísticas en tiempo real
- 🎨 Interfaz moderna y responsive
- 💾 Exportación/importación de datos
- 📱 Compatible con móviles y tablets

## 🚀 Deploy en Railway

1. Fork este repositorio
2. Conéctalo con Railway
3. Deploy automático
4. ¡Listo!

## 🔧 Uso Local
```bash
npm install
npm start
```